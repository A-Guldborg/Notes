import java.util.ArrayList;

public class Hotel {
    private String name;
    private Room[][] rooms;
    private ArrayList<Booking> bookings;

    public Hotel(String name, int floors, int roomsPerFloor) {
        this.name = name;
        rooms = buildHotel(floors, roomsPerFloor);
        bookings = new ArrayList<>();
    }

    /* Tilføjer en ny booking til listen bookings. */
    public void addBooking(String contact, int guests, boolean breakfast, int requestedFloor, int requestedRoomNo) {
        Room requestedRoom = rooms[requestedFloor][requestedRoomNo];
        bookings.add(new Booking(contact, guests, breakfast, requestedRoom));
        requestedRoom.setBooked();
    }

    /* Udregner det gennemsnitlige antal gæster per booking. */
    public double avgGuests() {
        int sum = 0;
        for (Booking b : bookings) {
            sum += b.getGuests();
        }
        return sum / bookings.size();
    }

    /* Hjælpemetode til constructoren.
       Opretter Room-objekter, som den tilføjer til rooms. */
    private Room[][] buildHotel(int floors, int roomsPerFloor) {
        Room[][] hotel = new Room[floors][roomsPerFloor];
        for (int i = 0; i < hotel.length; i++) {
            for (int j = 0; j < hotel[i].length; j++) {
                hotel[i][j] = new Room(i, j);
            }
        }
        return hotel;
    }
    
    /** SKRIV DIN KODE HERUNDER */
}