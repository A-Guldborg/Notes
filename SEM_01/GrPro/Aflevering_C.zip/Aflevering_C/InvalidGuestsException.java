public class InvalidGuestsException extends Exception {
    public InvalidGuestsException() {
        super("Invalid number of guests");
    }
}
