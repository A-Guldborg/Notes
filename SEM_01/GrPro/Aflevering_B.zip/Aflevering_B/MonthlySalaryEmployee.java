import java.util.ArrayList;

public class MonthlySalaryEmployee extends PermanentEmployee {
    public MonthlySalaryEmployee(String name, double salary) {
        super(name, salary);
    }
}
