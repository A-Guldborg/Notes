package bfst22.factorial;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FactorialTest {
    @Test 
    void factorialOf0() {
        Factorial math = new Factorial();
        assertEquals(math.factorial(0), 1, "factorial(0) should return 1");
    }
}
